"""Core knowledge base abstractions."""
