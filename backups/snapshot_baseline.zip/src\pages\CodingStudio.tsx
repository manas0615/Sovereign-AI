import React, { useState } from 'react';
import { api } from '../api/client';
import { CodeExecuteResponse } from '../types/api';
import { 
  Play, Terminal, Copy, Check, Sparkles, Shield, 
  RotateCcw, CheckCircle2, AlertCircle, FileCode, Layers, Cpu 
} from 'lucide-react';
import clsx from 'clsx';

const CODING_TEMPLATES = [
  {
    id: 'corrosion',
    title: 'Pipeline Wall Degradation & Remaining Life',
    description: 'Calculates corrosion loss rate from inspection thickness telemetry and ASME B31.3 allowance.',
    code: `"""
Pipeline P-102 Ultrasonic Thickness & Degradation Calculation
Standard: ASME B31.3 Process Piping Corrosion Assessment
"""

import math

def calculate_degradation():
    pipe_nominal_mm = 12.70
    pipe_minimum_required_mm = 6.35
    corrosion_allowance_mm = 3.20
    
    # Telemetry measurements across inspection points
    points = [
        {"point_id": "UT-01", "thickness_mm": 9.40, "years_in_service": 5.0},
        {"point_id": "UT-02", "thickness_mm": 8.12, "years_in_service": 5.0},
        {"point_id": "UT-03", "thickness_mm": 7.85, "years_in_service": 5.0},
        {"point_id": "UT-04", "thickness_mm": 8.90, "years_in_service": 5.0},
    ]
    
    print("=" * 60)
    print("SOVEREIGN AI - PIPELINE P-102 CORROSION DEGRADATION SURVEY")
    print("=" * 60)
    
    min_measured = min(p["thickness_mm"] for p in points)
    critical_pt = next(p for p in points if p["thickness_mm"] == min_measured)
    
    loss_mm = pipe_nominal_mm - min_measured
    corrosion_rate_mm_yr = loss_mm / critical_pt["years_in_service"]
    remaining_wall_above_min = min_measured - pipe_minimum_required_mm
    estimated_remaining_life_yrs = remaining_wall_above_min / corrosion_rate_mm_yr if corrosion_rate_mm_yr > 0 else 999.0
    
    print(f"Nominal Wall Thickness:     {pipe_nominal_mm:.2f} mm")
    print(f"Minimum Allowable Wall:     {pipe_minimum_required_mm:.2f} mm")
    print(f"Corrosion Allowance:        {corrosion_allowance_mm:.2f} mm")
    print(f"Most Severe Point:          {critical_pt['point_id']} ({min_measured:.2f} mm)")
    print(f"Total Thickness Loss:       {loss_mm:.2f} mm")
    print(f"Corrosion Rate:             {corrosion_rate_mm_yr:.3f} mm/year")
    print(f"Estimated Remaining Life:   {estimated_remaining_life_yrs:.1f} years")
    
    compliance = "COMPLIANT" if min_measured >= (pipe_nominal_mm - corrosion_allowance_mm) else "EXCEEDED ALLOWANCE"
    print(f"Compliance Status:          {compliance}")
    print("=" * 60)
    return {"compliance": compliance, "rate": corrosion_rate_mm_yr, "remaining_years": estimated_remaining_life_yrs}

if __name__ == "__main__":
    calculate_degradation()
`
  },
  {
    id: 'seal_wear',
    title: 'Equipment V-204 Seal Wear Compliance',
    description: 'Evaluates mechanical seal clearance against manufacturer threshold (0.10mm).',
    code: `"""
Equipment V-204 Mechanical Seal Tolerance & Delta Assessment
Governed Bounded Execution
"""

def evaluate_v204_seal():
    equipment_tag = "V-204"
    allowable_threshold_mm = 0.10
    measured_seal_wear_mm = 0.18
    
    delta_mm = measured_seal_wear_mm - allowable_threshold_mm
    exceedance_pct = (delta_mm / allowable_threshold_mm) * 100.0
    is_exceeded = measured_seal_wear_mm > allowable_threshold_mm
    
    print(f"--- EQUIPMENT {equipment_tag} SEAL WEAR EVALUATION ---")
    print(f"Manufacturer Tolerance:     {allowable_threshold_mm:.2f} mm")
    print(f"Actual Measured Wear:       {measured_seal_wear_mm:.2f} mm")
    print(f"Tolerance Exceeded:         {is_exceeded}")
    print(f"Exceedance Delta:           +{delta_mm:.2f} mm (+{exceedance_pct:.1f}%)")
    
    if is_exceeded:
        print("ACTION REQUIRED: Immediate mechanical seal cartridge replacement.")
        print("GOVERNANCE STATUS: NON-COMPLIANT")
    else:
        print("ACTION REQUIRED: Routine scheduled monitoring.")
        print("GOVERNANCE STATUS: COMPLIANT")
    return {"exceeded": is_exceeded, "delta": delta_mm}

if __name__ == "__main__":
    evaluate_v204_seal()
`
  },
  {
    id: 'vibration',
    title: 'Turbine T-501 Vibration & ISO 10816 Zone',
    description: 'Assesses bearing vibration RMS velocity against ISO 10816-3 Zone C boundary.',
    code: `"""
Turbine T-501 Bearing Vibration & ISO 10816-3 Boundary Analysis
"""

def evaluate_vibration_zones():
    tag = "Turbine T-501"
    # ISO 10816-3 Class III/IV Large Machines (Rigid Support)
    # Zone A: < 2.3 mm/s (Good)
    # Zone B: 2.3 - 4.5 mm/s (Acceptable)
    # Zone C: 4.5 - 7.1 mm/s (Restricted Operation)
    # Zone D: > 7.1 mm/s (Danger / Trip)
    
    measurements = [
        {"bearing": "Drive End (DE)", "velocity_rms_mms": 5.82, "temp_c": 78.4},
        {"bearing": "Non-Drive End (NDE)", "velocity_rms_mms": 3.14, "temp_c": 64.2},
        {"bearing": "Thrust Bearing", "velocity_rms_mms": 6.45, "temp_c": 82.1}
    ]
    
    print(f"=== ISO 10816-3 VIBRATION AUDIT: {tag} ===")
    for b in measurements:
        vel = b["velocity_rms_mms"]
        if vel < 2.3:
            zone = "Zone A (Good)"
        elif vel <= 4.5:
            zone = "Zone B (Acceptable)"
        elif vel <= 7.1:
            zone = "Zone C (Unrestricted Operation Disallowed - Alert)"
        else:
            zone = "Zone D (Critical Trip Threshold Exceeded)"
            
        print(f"• {b['bearing']}: {vel:.2f} mm/s RMS, {b['temp_c']:.1f}°C -> {zone}")
        
    print("RECOMMENDATION: Schedule vibration balancing & lubrication audit.")

if __name__ == "__main__":
    evaluate_vibration_zones()
`
  }
];

export function CodingStudio() {
  const [code, setCode] = useState(CODING_TEMPLATES[0].code);
  const [executionResult, setExecutionResult] = useState<CodeExecuteResponse | null>(null);
  const [isExecuting, setIsExecuting] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleRunCode = async () => {
    if (!code.trim() || isExecuting) return;
    setIsExecuting(true);
    try {
      const res = await api.executeCode({ code });
      setExecutionResult(res);
    } catch (err: any) {
      setExecutionResult({
        success: false,
        stdout: '',
        stderr: err.message || 'Execution failed',
        exit_code: -1,
        duration_ms: 0,
        security_mode: 'DEGRADED',
        error: err.message
      });
    } finally {
      setIsExecuting(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSelectTemplate = (templateCode: string) => {
    setCode(templateCode);
    setExecutionResult(null);
  };

  return (
    <div className="flex flex-col h-full w-full bg-slate-950 text-slate-100 overflow-hidden select-text">
      {/* Top Bar */}
      <div className="h-14 flex items-center justify-between px-6 border-b border-slate-800/80 bg-slate-900/60 backdrop-blur flex-shrink-0">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 text-sm font-semibold text-white">
            <Terminal className="w-4 h-4 text-cyan-400" />
            <span>P04 Governed Conversational Coding Studio</span>
          </div>
          <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
            Sandbox: Localhost Subprocess Bounded
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-medium border border-slate-800 transition-colors cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
            <span>{copied ? 'Copied' : 'Copy Code'}</span>
          </button>

          <button
            onClick={handleRunCode}
            disabled={isExecuting || !code.trim()}
            className="flex items-center gap-2 px-5 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold shadow-sm transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
          >
            {isExecuting ? (
              <span className="animate-pulse">Executing in P04...</span>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Execute Script</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Split Body */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden">
        {/* Left Pane: Templates & Presets (4 cols) */}
        <div className="lg:col-span-4 border-r border-slate-800/80 bg-slate-900/40 p-5 overflow-y-auto space-y-4">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-300 uppercase tracking-wider">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <span>Industrial Analysis Presets</span>
          </div>

          <div className="space-y-3">
            {CODING_TEMPLATES.map((tmpl) => (
              <button
                key={tmpl.id}
                onClick={() => handleSelectTemplate(tmpl.code)}
                className="w-full text-left p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-cyan-500/50 hover:bg-slate-850 transition-all group cursor-pointer space-y-1.5"
              >
                <h4 className="text-xs font-semibold text-slate-200 group-hover:text-cyan-300 transition-colors">
                  {tmpl.title}
                </h4>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  {tmpl.description}
                </p>
                <div className="pt-1 flex items-center justify-between text-[10px] text-slate-500 font-mono">
                  <span>Load Preset →</span>
                </div>
              </button>
            ))}
          </div>

          <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-2 text-xs text-slate-400">
            <div className="flex items-center gap-2 font-semibold text-slate-300">
              <Shield className="w-3.5 h-3.5 text-cyan-400" />
              <span>P04 Security Boundaries</span>
            </div>
            <p className="text-[11px] leading-relaxed">
              Code executes in a dedicated temporary workspace with hard timeouts (10s), environment sanitization, and output byte limits (64KB).
            </p>
          </div>
        </div>

        {/* Right Pane: Code Editor & Console Output (8 cols) */}
        <div className="lg:col-span-8 flex flex-col h-full overflow-hidden bg-slate-950">
          {/* Editor Area */}
          <div className="flex-1 flex flex-col min-h-0 border-b border-slate-800">
            <div className="px-4 py-2 bg-slate-900/80 border-b border-slate-800/80 flex items-center justify-between text-xs text-slate-400 font-mono">
              <div className="flex items-center gap-2">
                <FileCode className="w-3.5 h-3.5 text-cyan-400" />
                <span>workspace/__task_exec__.py</span>
              </div>
              <span>Python 3.11</span>
            </div>
            <textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="flex-1 w-full bg-slate-950 p-4 font-mono text-xs text-slate-200 focus:outline-none resize-none leading-relaxed scrollbar-thin scrollbar-thumb-slate-800"
              spellCheck={false}
            />
          </div>

          {/* Execution Console Area */}
          <div className="h-64 flex flex-col bg-slate-950 font-mono text-xs overflow-hidden">
            <div className="px-4 py-2 bg-slate-900 border-b border-slate-800 flex items-center justify-between text-slate-400 flex-shrink-0">
              <div className="flex items-center gap-2">
                <Terminal className="w-3.5 h-3.5 text-cyan-400" />
                <span className="font-semibold text-slate-300">Execution Output (stdout / stderr)</span>
              </div>
              {executionResult && (
                <div className="flex items-center gap-3">
                  <span className={clsx(
                    "px-2 py-0.5 rounded text-[10px] font-bold border",
                    executionResult.exit_code === 0
                      ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                      : "bg-red-500/10 text-red-400 border-red-500/20"
                  )}>
                    Exit Code: {executionResult.exit_code}
                  </span>
                  <span>{executionResult.duration_ms}ms</span>
                </div>
              )}
            </div>

            <div className="flex-1 p-4 overflow-y-auto scrollbar-thin scrollbar-thumb-slate-800 space-y-2">
              {isExecuting ? (
                <div className="flex items-center gap-2 text-cyan-400 animate-pulse">
                  <Terminal className="w-4 h-4" />
                  <span>Executing in bounded Python sandbox...</span>
                </div>
              ) : executionResult ? (
                <>
                  {executionResult.stdout && (
                    <pre className="text-emerald-300 whitespace-pre-wrap leading-relaxed">
                      {executionResult.stdout}
                    </pre>
                  )}
                  {executionResult.stderr && (
                    <pre className="text-red-400 whitespace-pre-wrap leading-relaxed">
                      {executionResult.stderr}
                    </pre>
                  )}
                  {!executionResult.stdout && !executionResult.stderr && (
                    <span className="text-slate-500 italic">Script executed with no output.</span>
                  )}
                </>
              ) : (
                <span className="text-slate-600 italic">Click "Execute Script" above to run this code inside the P04 sandbox.</span>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
