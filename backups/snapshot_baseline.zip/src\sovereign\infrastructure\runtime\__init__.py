"""Llama.cpp runtime implementations."""
