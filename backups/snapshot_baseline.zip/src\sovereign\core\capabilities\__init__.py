"""Core capabilities abstractions."""
