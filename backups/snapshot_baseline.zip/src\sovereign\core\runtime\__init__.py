"""Model runtime abstractions."""
