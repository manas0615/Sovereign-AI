"""Core artifact package."""
