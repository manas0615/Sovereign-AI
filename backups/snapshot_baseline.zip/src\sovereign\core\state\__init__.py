"""Core state abstractions."""
