"""Infrastructure for persistent state."""
