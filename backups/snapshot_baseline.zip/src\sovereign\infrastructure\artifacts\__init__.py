"""Infrastructure for artifacts package."""
