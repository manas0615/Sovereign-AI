"""Infrastructure for knowledge base."""
